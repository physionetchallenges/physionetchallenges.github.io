#!/bin/bash -e

# This script will be run to evaluate a Challenge record; the name of
# the record will be passed on the command line (as $1).  Your program
# should decide whether the record depicts a true or false alarm, and
# add its response to the file 'answers.txt'.

RECORD=$1

perl ./challenge.pl $RECORD >> answers.txt
