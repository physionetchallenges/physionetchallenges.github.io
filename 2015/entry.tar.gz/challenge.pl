#!/usr/bin/perl -w

use strict;

my $record = $ARGV[0];
$record =~ s/\.hea$//;

my $alarm_time = 5*60;

# Examine record to determine length, alarm type, and available signals.

my $alarm_type;
my @ecg_signals;
my @pulse_signals;
my $record_length;
my $samp_freq;

open WFDBDESC, '-|', "wfdbdesc $record";
while (<WFDBDESC>) {
  if (/^=/) {
    # first info string is alarm message
    chomp ($alarm_type = <WFDBDESC>);
    while (<WFDBDESC>) {
      last if /^=/;
    }
  }
  elsif (/^Length:.*\((\d+) sample intervals\)/) {
    $record_length = $1;
  }
  elsif (/^Sampling frequency: ([0-9.]+)/) {
    $samp_freq = $1;
  }
  elsif (/^ Description: (I|II|III|aVL|aVR|aVF|V)$/) {
    push @ecg_signals, $1;
  }
  elsif (/^ Description: (ABP|PLETH)$/) {
    push @pulse_signals, $1;
  }
}
close WFDBDESC;

################################################################

# Analyze each ECG channel with gqrs; return a list of annotators.
sub gqrs_all {
  my @annotators;
  foreach my $sig (@ecg_signals) {
    system "gqrs -r $record -s $sig -o qrs >&2";
    system "gqpost -r $record -a qrs -o q$sig >&2";
    push @annotators, "q$sig";
  }
  return @annotators;
}

# Analyze each pulsatile channel with wabp; return a list of
# annotators.
sub wabp_all {
  my @annotators;
  foreach my $sig (@pulse_signals) {
    system "wabp -r $record -s $sig >&2";
    rename "$record.wabp", "$record.q$sig";
    push @annotators, "q$sig";
  }
  return @annotators;
}

# Merge a set of annotators with gqfuse
sub gqfuse {
  my @annotators = @_;
  system "gqfuse -r $record -a @annotators >&2";
  return "gqf";
}

# Read beat annotations; return a list of RR intervals (where each
# element is an array [ $START, $LENGTH, $END ].)
sub ann2rr {
  my ($annotator) = @_;
  my @rr;
  my $prev_beat = 0;
  open RDANN, '-|', "rdann -r $record -a $annotator";
  while (<RDANN>) {
    if (/^\s*\S+\s+(\d+)\s+N/) {
      my $t = ($1 / $samp_freq);
      push @rr, [ $prev_beat, ($t - $prev_beat), $t ];
      $prev_beat = $t;
    }
  }
  close RDANN;
  my $t = ($record_length / $samp_freq);
  push @rr, [ $prev_beat, ($t - $prev_beat), $t ];
  return @rr;
}

################################################################

sub check_alarm {
  my ($alarm) = @_;

  if ($alarm eq 'Asystole') {
    # analyze all channels; convert best set of beat annotations to a
    # series of RR intervals
    my @rr = ann2rr(gqfuse(gqrs_all(), wabp_all()));
    foreach my $rr (@rr) {
      # true if an RR interval is longer than 4 seconds
      if ($rr->[1] >= 4 &&
          $rr->[0] <= $alarm_time - 3 &&
          $rr->[0] >= $alarm_time - 18) {
        return 1;
      }
    }
    return 0;
  }
  elsif ($alarm eq 'Bradycardia') {
    # analyze all channels; convert best set of beat annotations to a
    # series of RR intervals
    my @rr = ann2rr(gqfuse(gqrs_all(), wabp_all()));
    my @rr_seq;
    foreach my $rr (@rr) {
      # true if a sequence of 4 RR intervals is longer than 6 seconds
      push @rr_seq, $rr;
      if (@rr_seq == 4) {
        my $dt = $rr->[2] - $rr_seq[0]->[0];
        if ($dt >= 6 &&
            $rr->[2] <= $alarm_time &&
            $rr->[2] >= $alarm_time - 15) {
          return 1;
        }
        shift @rr_seq;
      }
    }
    return 0;
  }
  elsif ($alarm eq 'Tachycardia') {
    # analyze all channels; convert best set of beat annotations to a
    # series of RR intervals
    my @rr = ann2rr(gqfuse(gqrs_all(), wabp_all()));
    my @rr_seq;
    foreach my $rr (@rr) {
      # true if a sequence of 16 RR intervals is shorter than 6.86 seconds
      push @rr_seq, $rr;
      if (@rr_seq == 16) {
        my $dt = $rr->[2] - $rr_seq[0]->[0];
        if ($dt <= 6.86 &&
            $rr->[2] <= $alarm_time &&
            $rr->[2] >= $alarm_time - 15) {
          return 1;
        }
        shift @rr_seq;
      }
    }
    return 0;
  }
  elsif ($alarm eq 'Ventricular_Flutter_Fib') {
    # analyze ECG and pulsatile channels separately and convert each
    # to a series of RR intervals
    my @rr = ann2rr(gqfuse(gqrs_all()));
    my @pp = ann2rr(gqfuse(wabp_all()));
    if (!@rr || !@pp) {
      return 1;
    }
    # look for a 10-second interval in which the numbers of beats from
    # ECG and pulsatile signals agree (+/- 2 beats), followed by a
    # 3-second interval in which the QRS rate increases and the pulse
    # rate dramatically decreases
    for (my $t = 0; $t < $alarm_time - 13; $t += 0.25) {
      my $nq_w1 = grep { $_->[0] >= $t && $_->[0] < $t+10 } @rr;
      my $np_w1 = grep { $_->[0] >= $t && $_->[0] < $t+10 } @pp;
      my $nq_w2 = grep { $_->[0] >= $t+10 && $_->[0] < $t+13 } @rr;
      my $np_w2 = grep { $_->[0] >= $t+10 && $_->[0] < $t+13 } @pp;
      if ($np_w1 >= $nq_w1 - 2 &&
          $np_w1 <= $nq_w1 + 2 &&
          $nq_w2 >= $nq_w1 * (3/10) * 1.25 &&
          $np_w2 <= $np_w1 * (3/10) * 0.25) {
        return 1;
      }
    }
    return 0;
  }
  elsif ($alarm eq 'Ventricular_Tachycardia') {
    return 1;
  }
  else {
    die "unknown alarm type '$alarm'";
  }
}

my $answer = check_alarm($alarm_type);
print "$record,$answer\n";

# Clean up temporary files
unlink "$record.qrs";
unlink "$record.gqf";
foreach my $s (@ecg_signals, @pulse_signals) {
  unlink "$record.q$s";
}
