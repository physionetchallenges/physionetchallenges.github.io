#!/bin/bash -e

# This script will be run after the entry is unpacked.  Please include
# all commands needed to compile your program from source code.

exit 0
